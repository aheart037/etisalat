<?php
/* @wordpress-plugin
 * Plugin Name:       Etisalat  Payment Gateway
 * Description:       Etisalat Payment Gateway.
 * Version:           4.0
 * Created by:       Etisalat E-Commerce Team.
 */

$active_plugins = apply_filters('active_plugins', get_option('active_plugins'));
if(Etisalat_custom_payment_is_woocommerce_active()){
	add_filter('woocommerce_payment_gateways', 'Etisalat_payment_gateway');
	function Etisalat_payment_gateway( $gateways ){
		$gateways[] = 'WC_Etisalat_Payment_Gateway';
		return $gateways; 
	}

	add_action('plugins_loaded', 'init_Etisalat_payment_gateway');
	function init_Etisalat_payment_gateway(){
		require 'class-woocommerce-Etisalat-payment-gateway.php';
	}

	add_action( 'plugins_loaded', 'Etisalat_payment_load_plugin_textdomain' );
	function Etisalat_payment_load_plugin_textdomain() {
	  load_plugin_textdomain( 'woocommerce-Etisalat-payment-gateway', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
	}



}


/**
 * @return bool
 */
function Etisalat_custom_payment_is_woocommerce_active()
{
	$active_plugins = (array) get_option('active_plugins', array());

	if (is_multisite()) {
		$active_plugins = array_merge($active_plugins, get_site_option('active_sitewide_plugins', array()));
	}

	return in_array('woocommerce/woocommerce.php', $active_plugins) || array_key_exists('woocommerce/woocommerce.php', $active_plugins);
}