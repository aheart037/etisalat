<?php 
		//phpinfo();
		require('../../../wp-load.php');
		global $woocommerce;
		
		if(isset($_GET["OrderID"]))
		{
			$order_id = $_GET["OrderID"];
			$order_id = stripslashes($order_id);
			$order_id = str_replace('"', '', $order_id);
		}
		else
		{
			print "<br />order id not exist, Please try again<br />";
			exit();	
		}
		
		$order = new WC_Order( $order_id );
		//$order_data = $order->get_data();
		$response_curlerror = ""; 
		$response_curl = ""; 
		$payment_gateway_id = 'other_payment';
		$payment_gateways   = WC_Payment_Gateways::instance();
		$payment_gateway    = $payment_gateways->payment_gateways()[$payment_gateway_id];
		$ReturnPath = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://';
		$ReturnPath .= $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']).'/Response.php?OrderID="'.$order_id.'"';
		//print "Returnpath :" .$ReturnPath. "<br />";
		//exit();
		$ch = curl_init($payment_gateway->GatewayURL);	
		$arr_sendRequest = array();
		$arr_sendRequest['Currency'] = $order->get_currency();
		$arr_sendRequest['TransactionHint'] = $payment_gateway->TransactionHint;
		$arr_sendRequest['OrderID'] = 	$order_id ;
		$arr_sendRequest['OrderName'] = "Donation #$order_id";
		$arr_sendRequest['OrderInfo'] = "Donation for Almarah Foundation";
		$arr_sendRequest['Channel'] = 	"Web";
		$arr_sendRequest['Amount'] =  $order->get_total();
		$arr_sendRequest['Customer'] = $payment_gateway->MerchantID;
		$arr_sendRequest['Store'] 	= 	$payment_gateway->Store;
		$arr_sendRequest['Terminal'] = $payment_gateway->Terminal;
		$arr_sendRequest['UserName'] = $payment_gateway->UserName;
		$arr_sendRequest['Password'] = $payment_gateway->Password;
		$arr_sendRequest['ReturnPath'] = $ReturnPath;
		$jonRequest = json_encode(array('Registration' => $arr_sendRequest), JSON_FORCE_OBJECT);
		
		//print "Json-submitted".$jonRequest;
		
		curl_setopt($ch, CURLOPT_HEADER, 0); 
		curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Accept:text/xml-standard-api'));
		curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
		curl_setopt($ch, CURLOPT_PORT, 2443);
		curl_setopt($ch, CURLOPT_SSLVERSION, 6);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt( $ch, CURLOPT_POSTFIELDS, $jonRequest );
		curl_setopt($ch, CURLOPT_CAINFO, dirname(__FILE__) . "/ca.crt");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$response_curl = curl_exec($ch);
				
		if (curl_errno($ch)) 
		{
			$response_curlerror = curl_error($ch);
			print "<br />Error While Processing the Registration Request, Please try again<br />";
			curl_close($ch);
			exit();	
		}
		curl_close($ch);
		
		$response = json_decode($response_curl, true);
		
			if (isset($response['Transaction']['ResponseCode']) 
			&& ($response['Transaction']['ResponseCode'] == 0))
			{ 	
				echo '<center style="font-family: Arial, sans-serif; font-size: 20px; font-weight: bold; color: #333; margin-top: 50px;">
        You are being re-directed to <span style="color: #3498db;">Etisalat Payment Gateway</span>.
      </center><form method="post" id="etisalat-redirect-form" name="redirect" action="'.$response['Transaction']['PaymentPage'].'"/><input type="Hidden" name="TransactionID" value="'.$response['Transaction']['TransactionID'].'"/></form><script type="text/javascript">document.redirect.submit();</script>';
				
			}
			else
			{
		print "<div style='font-family: Arial, sans-serif; border: 1px solid #f00; padding: 20px; background-color: #ffe6e6; color: #a00; width: 80%; margin: 20px auto; border-radius: 8px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);'>";
    print "<h3 style='color: #900; margin-top: 0; display: flex; align-items: center;'><span style='font-size: 24px; margin-right: 10px;'>⚠️</span>Oops! Payment Error</h3>";
    print "<p style='margin: 5px 0;'><strong>Response Code:</strong> " . $response['Transaction']['ResponseCode'] . "</p>";
    print "<p style='margin: 5px 0;'><strong>Description:</strong> " . $response['Transaction']['ResponseDescription'] . "</p>";
    print "<p style='margin: 5px 0;'><strong>Class Description:</strong> " . $response['Transaction']['ResponseClassDescription'] . "</p>";
    echo "<form name='Request' action='https://almarah.org/donate/' method='get' style='margin-top: 15px;'>";
    echo "<input type='submit' value='Back to Donation Page' style='padding: 10px 20px; background-color: #900; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-size: 16px;'>";
    echo "</form>";
    print "</div>";
				
			}