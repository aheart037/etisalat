<?php 

require('../../../wp-load.php');
global $woocommerce;

// Log enabled
if (isset($_POST["TransactionID"])) {
    $TransactionID = $_POST["TransactionID"];
} else {
    display_error("TransactionID does not exist. Please try again.");
    exit();    
}

if (isset($_GET["OrderID"])) {
    $order_id = $_GET["OrderID"];
    $order_id = stripslashes($order_id);
    $order_id = str_replace('"', '', $order_id);
} else {
    display_error("Order ID does not exist. Please try again.");
    exit();    
}

$order = new WC_Order($order_id);
custom_logs("--------Initializing the Transaction Finalization Process -> V.4.0 ");
custom_logs("TransactionID - " . $TransactionID);
custom_logs("OrderID - " . $order_id);

$response_curlerror = ""; 
$response_curl = ""; 
$payment_gateway_id = 'other_payment';
$payment_gateways = WC_Payment_Gateways::instance();
$payment_gateway = $payment_gateways->payment_gateways()[$payment_gateway_id];

$ch = curl_init($payment_gateway->GatewayURL); 
$arr_sendRequest = array();
$arr_sendRequest['TransactionID'] = $TransactionID;
$arr_sendRequest['Customer'] = $payment_gateway->MerchantID;
$arr_sendRequest['UserName'] = $payment_gateway->UserName;
$arr_sendRequest['Password'] = $payment_gateway->Password;
$jonRequest = json_encode(array('Finalization' => $arr_sendRequest), JSON_FORCE_OBJECT);        

curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json', 'Accept:text/xml-standard-api'));
curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
curl_setopt($ch, CURLOPT_PORT, 2443);
curl_setopt($ch, CURLOPT_SSLVERSION, 6);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jonRequest);
curl_setopt($ch, CURLOPT_CAINFO, dirname(__FILE__) . "/ca.crt");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response_curl = curl_exec($ch);

if (curl_errno($ch)) {
    $response_curlerror = curl_error($ch);
    custom_logs("--------Error While Processing the Transaction---------");
    display_error("Error while processing the transaction. Please try again.");
    curl_close($ch);
    exit();    
}
curl_close($ch);

$response = json_decode($response_curl, true);

custom_logs("Response Code - " . $response['Transaction']['ResponseCode']);
custom_logs("Response Description - " . $response['Transaction']['ResponseDescription']);

if (isset($response['Transaction']['ResponseCode']) 
    && isset($response['Transaction']['ApprovalCode'])
    && ($response['Transaction']['ResponseCode'] == 0)) { 

    $order->payment_complete();
    wc_reduce_stock_levels($order_id);
    $woocommerce->cart->empty_cart();
    $message = "Payment has been processed successfully" . "\r\n" . 
               "TransactionID: " . $TransactionID . "\r\n" .  
               "Response Code: " . $response['Transaction']['ResponseCode'] . "\r\n" . 
               "ApprovalCode: " . $response['Transaction']['ApprovalCode'];
    $order->add_order_note(nl2br($message), true);
    custom_logs("--------Process Completed Successfully---------");
    $return_url = $payment_gateway->get_return_url($order);
    echo '<form method="post" id="etisalat-redirect-form" name="redirect" action="' . $return_url . '">
            <input type="hidden" name="TransactionID" value="' . $TransactionID . '"/>
          </form>
          <script type="text/javascript">document.redirect.submit();</script>';
} else {    
    display_error("Error Details:<br />" .
        "Response Code: " . $response['Transaction']['ResponseCode'] . "<br />" . 
        "Description: " . $response['Transaction']['ResponseDescription'] . "<br />" . 
        "Class Description: " . $response['Transaction']['ResponseClassDescription']);
    
    $message = "Payment Failed for TransactionID " . $TransactionID . "\r\n" . 
               "Response Code: " . $response['Transaction']['ResponseCode'];
    $order->add_order_note(nl2br($message), true);
    custom_logs("--------Process Completed With Failure Response---------");

    echo "<br>";
    echo '<a href="https://almarah.org/donate/" style="
            display: inline-block; 
            padding: 10px 20px; 
            margin-top: 20px; 
            background-color: #007bff; 
            color: #fff; 
            text-align: center; 
            border-radius: 5px; 
            text-decoration: none; 
            font-weight: bold;">
            Back to Donation Page
          </a>';
}

function custom_logs($logmessage) { 
    if (is_array($logmessage)) { 
        $logmessage = json_encode($logmessage); 
    } 
    $file = fopen("../Transactionlogs.log", "a"); 
    fwrite($file, "\n" . date('Y-m-d h:i:s') . " : " . $logmessage); 
    fclose($file); 
}

function display_error($message) {
    echo '<div style="
            padding: 15px; 
            margin: 20px; 
            border: 1px solid red; 
            background-color: #f8d7da; 
            color: #721c24; 
            border-radius: 5px;">
            <strong>Error!</strong> ' . $message . '
          </div>';
}

?>