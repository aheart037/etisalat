<?php 

class WC_Etisalat_Payment_Gateway extends WC_Payment_Gateway{

	public function __construct(){
		$this->id = 'other_payment';
		$this->method_title = __('Etisalat Payment Gateway','woocommerce-Etisalat-payment-gateway');
		$this->title = __('Etisalat Payment Gateway','woocommerce-Etisalat-payment-gateway');
        $this->method_description = 'Powered by Etisalat, a secure and fast method to complete your transaction with multiple methods including: Apple Pay, Visa / Mastercard, Samsung Pay, etc.';
		$this->has_fields = true;
		$this->init_form_fields();
		$this->init_settings();
		$this->enabled = $this->get_option('enabled');
		$this->title = $this->get_option('title');
		$this->description = $this->get_option('description');
		$this->hide_text_box = $this->get_option('hide_text_box');
		$this->MerchantID = $this->get_option('MerchantID');
		$this->TransactionHint = $this->get_option('TransactionHint');
		$this->Store = $this->get_option('Store');
		$this->Terminal = $this->get_option('Terminal');
		$this->GatewayURL = $this->get_option('GateWay');
		$this->UserName = $this->get_option('UserName');
		$this->Password = $this->get_option('Password');
		

		add_action('woocommerce_update_options_payment_gateways_'.$this->id, array($this, 'process_admin_options'));
	}
	public function init_form_fields(){
				$this->form_fields = array(
					'enabled' => array(
					'title' 		=> __( 'Enable/Disable', 'woocommerce-Etisalat-payment-gateway' ),
					'type' 			=> 'checkbox',
					'label' 		=> __( 'Etisalat Custom Payment', 'woocommerce-Etisalat-payment-gateway' ),
					'default' 		=> 'yes'
					),
					'title' => array(
						'title' 		=> __( 'Method Title', 'woocommerce-Etisalat-payment-gateway' ),
						'type' 			=> 'text',
						'description' 	=> __( 'This controls the title', 'woocommerce-Etisalat-payment-gateway' ),
						'default'		=> __( 'Custom Payment', 'woocommerce-Etisalat-payment-gateway' ),
						'desc_tip'		=> true,
					),
                    'description' => array(
                    'title' => 'Description',
                    'type' => 'textarea',
                    'description' => 'This controls the description which the user sees during checkout.',
                 'default' => '<p style="font-size: 16px; font-weight: bold; color: #333;">
        Secure Payment with Credit/Debit Card
    </p>
    <p style="font-size: 14px; color: #666;">
        We accept all major credit and debit cards for a hassle-free transaction.
    </p>
    <div style="display: flex; justify-content: center; align-items: center; gap: 5px;">
        <img src="https://almarah.org/wp-content/uploads/2025/03/UBL-Pay-Visa-Mastercard-logo-scaled.gif" 
             alt="UBLPay" width="100">
    </div>'
                ),
					'TransactionHint' => array(
						'title' 		=> __( 'TransactionHint', 'woocommerce-Etisalat-payment-gateway' ),
						'type' 			=> 'text',
						'description' 	=> __( 'Parameters', 'woocommerce-Etisalat-payment-gateway' ),
						'default'		=> __( 'TransactionHint', 'woocommerce-Etisalat-payment-gateway' ),
						'desc_tip'		=> true,
					),
					'MerchantID' => array(
						'title' 		=> __( 'Merchant Name', 'woocommerce-Etisalat-payment-gateway' ),
						'type' 			=> 'text',
						'description' 	=> __( 'Customer Name', 'woocommerce-Etisalat-payment-gateway' ),
						'default'		=> __( 'Merchant Name', 'woocommerce-Etisalat-payment-gateway' ),
						'desc_tip'		=> true,
					),

					'Store' => array(
						'title' 		=> __( 'Store', 'woocommerce-Etisalat-payment-gateway' ),
						'type' 			=> 'text',
						'description' 	=> __( 'Store', 'woocommerce-Etisalat-payment-gateway' ),
						'default'		=> __( '', 'woocommerce-Etisalat-payment-gateway' ),
						'desc_tip'		=> true,
					),
					'Terminal' => array(
						'title' 		=> __( 'Terminal', 'woocommerce-Etisalat-payment-gateway' ),
						'type' 			=> 'text',
						'description' 	=> __( 'Terminal', 'woocommerce-Etisalat-payment-gateway' ),
						'default'		=> __( '', 'woocommerce-Etisalat-payment-gateway' ),
						'desc_tip'		=> true,
					),
					'GateWay' => array(
						'title' 		=> __( 'EPG URL', 'woocommerce-Etisalat-payment-gateway' ),
						'type' 			=> 'text',
						'description' 	=> __( 'Etisalat Gateway URL', 'woocommerce-Etisalat-payment-gateway' ),
						'default'		=> __( '', 'woocommerce-Etisalat-payment-gateway' ),
						'desc_tip'		=> true,
					),
					'UserName' => array(
						'title' 		=> __( 'UserName', 'woocommerce-Etisalat-payment-gateway' ),
						'type' 			=> 'text',
						'description' 	=> __( 'Etisalat Credentials(User Name)', 'woocommerce-Etisalat-payment-gateway' ),
						'default'		=> __( 'UserName', 'woocommerce-Etisalat-payment-gateway' ),
						'desc_tip'		=> true,
					),
					'Password' => array(
						'title' 		=> __( 'Password', 'woocommerce-Etisalat-payment-gateway' ),
						'type' 			=> 'password',
						'description' 	=> __( 'Etisalat Credentials(Password)', 'woocommerce-Etisalat-payment-gateway' ),
						'default'		=> __( 'Password', 'woocommerce-Etisalat-payment-gateway' ),
						'desc_tip'		=> true,
					),
			 );
	}


	
	public function process_payment( $order_id ) {
		global $woocommerce;
		
		$Requesturl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 'https://' : 'http://';
		$Requesturl .= $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']).'\wp-content\plugins\EtisalatPay\Request.php?OrderID="'.$order_id.'"';
		//print "Returnpath :" .$Requesturl. "<br />";
		//exit();
		
		return array(
				'result' => 'success',
				'redirect' => $Requesturl
			);	
	}	


}